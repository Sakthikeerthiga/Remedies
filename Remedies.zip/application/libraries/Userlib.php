<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Userlib

{





	

	public function emailconfig()

	{

	

		$config = Array(

			  'protocol' => 'smtp',

			  'smtp_host' => 'email-smtp.us-west-2.amazonaws.com',

			  'smtp_port' => 587,

			  'smtp_user' => 'AKIAJOVNVKOP5JNPSMUQ', // change it to yours

			  'smtp_pass' => 'Aq/Cqw+Z1qD2c0LZicIeFBe/Up3ums6qjTrgo1gDzClc', // change it to yours

			  'mailtype' => 'html',

			  'charset' => 'iso-8859-1',

			  'wordwrap' => TRUE,

			  'smtp_crypto' => 'tls'

						);

						

			return $config;

	

	}



	

	public function encryptor($action, $string) {

		

		$output = false;

		$encrypt_method = "AES-256-CBC";

		//pls set your unique hashing key

		$secret_key = 'muni';

		$secret_iv = 'muni123';



		// hash

		$key = hash('sha256', $secret_key);

		

		// iv - encrypt method AES-256-CBC expects 16 bytes - else you will get a warning

		$iv = substr(hash('sha256', $secret_iv), 0, 16);



		//do the encyption given text/string/number

		if( $action == 'encrypt' ) {

			$output = openssl_encrypt($string, $encrypt_method, $key, 0, $iv);

			$output = base64_encode($output);

		}

		else if( $action == 'decrypt' ){

			//decrypt the given text/string/number

			$output = openssl_decrypt(base64_decode($string), $encrypt_method, $key, 0, $iv);

		}



		return $output;

	}

	

	

}	

	?>