<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!-- header menu -->
<?php  $this->load->view('admin/includes/header_menu.php');?>
<div id="layoutSidenav_content">
<center> <b>Welcome</b></center>

    <!-- footer menu -->
    <?php  $this->load->view('admin/includes/footer_menu.php');?>
